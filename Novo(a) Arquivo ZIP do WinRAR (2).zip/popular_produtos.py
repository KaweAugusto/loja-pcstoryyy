import os
import django

# Configura o Django para usar as configurações do projeto
os.environ.setdefault('DJANGO_SETTINGS_MODULE', 'sistema_ecommerce.settings')
django.setup()

from produto.models import Categoria, Produto

# Categorias e produto iniciais
categorias = {
    "Placas-mãe": [
        {"nome": "ASUS Prime B450M", "preco": 650.00, "descricao": "Placa-mãe ASUS Prime B450M para processadores AMD Ryzen."},
        {"nome": "Gigabyte B550 Aorus", "preco": 900.00, "descricao": "Placa-mãe Gigabyte B550 Aorus para gamers exigentes."},
        {"nome": "MSI MPG X570", "preco": 1500.00, "descricao": "Placa-mãe MSI MPG X570 com suporte PCIe 4.0."},
        {"nome": "ASRock B450 Steel Legend", "preco": 720.00, "descricao": "Placa-mãe robusta e confiável para Ryzen."},
        {"nome": "Biostar B550MH", "preco": 500.00, "descricao": "Placa-mãe Biostar acessível para uso básico."}
    ],
    "Placas de vídeo": [
        {"nome": "NVIDIA RTX 3060", "preco": 2200.00, "descricao": "Placa de vídeo NVIDIA GeForce RTX 3060."},
        {"nome": "AMD RX 6600", "preco": 1800.00, "descricao": "Placa de vídeo AMD Radeon RX 6600."},
        {"nome": "NVIDIA GTX 1660 Super", "preco": 1200.00, "descricao": "Placa de vídeo NVIDIA GTX 1660 Super."},
        {"nome": "AMD RX 6800 XT", "preco": 3500.00, "descricao": "Placa de vídeo de alto desempenho da AMD."},
        {"nome": "NVIDIA RTX 4090", "preco": 15000.00, "descricao": "Placa de vídeo topo de linha da NVIDIA."}
    ],
    "Periféricos": [
        {"nome": "Teclado Mecânico Redragon", "preco": 250.00, "descricao": "Teclado mecânico com switches vermelhos."},
        {"nome": "Mouse Gamer Logitech G502", "preco": 350.00, "descricao": "Mouse gamer de alta precisão."},
        {"nome": "Headset HyperX Cloud II", "preco": 500.00, "descricao": "Headset confortável com som surround."},
        {"nome": "Monitor LG 24'' IPS", "preco": 700.00, "descricao": "Monitor LG Full HD painel IPS."},
        {"nome": "Webcam Logitech C920", "preco": 400.00, "descricao": "Webcam Full HD com ótima qualidade de imagem."}
    ]
}

# Criando categorias e produto
for nome_categoria, produtos_lista in categorias.items():
    categoria, _ = Categoria.objects.get_or_create(nome=nome_categoria)
    for prod in produtos_lista:
        Produto.objects.get_or_create(
            nome=prod["nome"],
            defaults={
                "preco": prod["preco"],
                "descricao": prod["descricao"],
                "categoria": categoria
            }
        )

print("✅ Produtos populados com sucesso!")
